<script src="{{ asset('assets/admin/js/app.js') }}"></script>
</body>
</html>
