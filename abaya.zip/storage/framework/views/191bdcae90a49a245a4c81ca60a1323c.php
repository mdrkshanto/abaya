<script src="<?php echo e(asset('assets/admin/js/app.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\laragon\www\abaya\resources\views/components/admin/includes/footer/index.blade.php ENDPATH**/ ?>