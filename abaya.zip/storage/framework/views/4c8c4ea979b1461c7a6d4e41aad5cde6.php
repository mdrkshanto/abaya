<?php if (isset($component)) { $__componentOriginal920bd896de9213e21cff781a16fc9278 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal920bd896de9213e21cff781a16fc9278 = $attributes; } ?>
<?php $component = App\View\Components\Admin\Index::resolve(['title' => 'Auth Info'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.index'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Admin\Index::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="card card-body">
        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert" id="successAlert">
                <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        <form action="<?php echo e(route('update.auth.info')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-md-4 my-2">
                    <label for="name" class="form-label">Username</label>
                    <input type="text" class="form-control shadow-none" value="<?php echo e($user->name); ?>" name="name"
                        id="name" />
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-danger"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-4 my-2">
                    <label for="mobile" class="form-label">Mobile</label>
                    <input type="text" class="form-control shadow-none" value="<?php echo e($user->mobile); ?>" name="mobile"
                        id="mobile" />
                    <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-danger"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-4 my-2">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" class="form-control shadow-none" value="<?php echo e($user->email); ?>" name="email"
                        id="email" />
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-danger"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <div class="row">
                <div class="col-12 my-2">
                    <label for="current-password" class="form-label">Current Password</label>
                    <input type="password" class="form-control shadow-none" name="current_password" />
                    <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-danger"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-12 my-2">
                    <label for="new-password" class="form-label">New Password</label>
                    <input type="password" class="form-control shadow-none" name="new_password" />
                    <?php $__errorArgs = ['new_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-danger"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="row justify-content-center">
                <button class="btn btn-sm btn-primary shadow-none col-md-4" type="submit">Submit</button>
            </div>
        </form>
    </div>

    <script>
        setTimeout(function() {
            var alert = document.getElementById('successAlert');
            if (alert) {
                var bsAlert = new bootstrap.Alert(alert);
                bsAlert.close();
            }
        }, 3000);
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal920bd896de9213e21cff781a16fc9278)): ?>
<?php $attributes = $__attributesOriginal920bd896de9213e21cff781a16fc9278; ?>
<?php unset($__attributesOriginal920bd896de9213e21cff781a16fc9278); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal920bd896de9213e21cff781a16fc9278)): ?>
<?php $component = $__componentOriginal920bd896de9213e21cff781a16fc9278; ?>
<?php unset($__componentOriginal920bd896de9213e21cff781a16fc9278); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\abaya\resources\views/admin/pages/auth/index.blade.php ENDPATH**/ ?>