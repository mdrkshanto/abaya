<?php if (isset($component)) { $__componentOriginalc5f982ced3df7c06ab765d9a822b052e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc5f982ced3df7c06ab765d9a822b052e = $attributes; } ?>
<?php $component = App\View\Components\Admin\Includes\Head\Index::resolve(['title' => ''.e(isset($title) ? $title . ' | ' . 'Abaya' : 'Abaya').''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.includes.head.index'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Admin\Includes\Head\Index::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc5f982ced3df7c06ab765d9a822b052e)): ?>
<?php $attributes = $__attributesOriginalc5f982ced3df7c06ab765d9a822b052e; ?>
<?php unset($__attributesOriginalc5f982ced3df7c06ab765d9a822b052e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc5f982ced3df7c06ab765d9a822b052e)): ?>
<?php $component = $__componentOriginalc5f982ced3df7c06ab765d9a822b052e; ?>
<?php unset($__componentOriginalc5f982ced3df7c06ab765d9a822b052e); ?>
<?php endif; ?>
<nav id="sidebar" class="sidebar js-sidebar">
    <div class="sidebar-content js-simplebar">
        <a class='sidebar-brand' href="<?php echo e(route('orders')); ?>">
            <span class="sidebar-brand-text align-middle">Abaya</span>
        </a>

        <ul class="sidebar-nav">
            <li class="sidebar-item<?php echo e(request()->routeIs('orders')?' active':null); ?>">
                <a href="<?php echo e(route('orders')); ?>" class="sidebar-link">
                    <i class="align-middle" data-feather="database"></i> <span class="align-middle">Orders</span>
                </a>
            </li>
            <li class="sidebar-item<?php echo e(request()->routeIs('auth.info')?' active':null); ?>">
                <a href="<?php echo e(route('auth.info')); ?>" class="sidebar-link">
                    <i class="align-middle" data-feather="key"></i> <span class="align-middle">Auth</span>
                </a>
            </li>
            <li class="sidebar-item">
                <a href="<?php echo e(route('logout')); ?>" class="sidebar-link">
                    <i class="align-middle" data-feather="log-out"></i> <span class="align-middle">Logout</span>
                </a>
            </li>
        </ul>
    </div>
</nav>

<div class="main">
    <nav class="navbar navbar-expand navbar-light navbar-bg">
        <span class="sidebar-toggle js-sidebar-toggle">
            <i class="hamburger align-self-center"></i>
        </span>
    </nav>

    <main class="content">
        <div class="container-fluid p-0">

            <?php if(isset($title)): ?>
                <h1 class="h3 mb-3"><?php echo e($title); ?></h1>
            <?php endif; ?>

            <?php echo e($slot); ?>


        </div>
    </main>
</div>
</div>
<?php if (isset($component)) { $__componentOriginal06e1036b74bdb54acf7e988d600ef1ba = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal06e1036b74bdb54acf7e988d600ef1ba = $attributes; } ?>
<?php $component = App\View\Components\Admin\Includes\Footer\Index::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.includes.footer.index'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Admin\Includes\Footer\Index::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal06e1036b74bdb54acf7e988d600ef1ba)): ?>
<?php $attributes = $__attributesOriginal06e1036b74bdb54acf7e988d600ef1ba; ?>
<?php unset($__attributesOriginal06e1036b74bdb54acf7e988d600ef1ba); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal06e1036b74bdb54acf7e988d600ef1ba)): ?>
<?php $component = $__componentOriginal06e1036b74bdb54acf7e988d600ef1ba; ?>
<?php unset($__componentOriginal06e1036b74bdb54acf7e988d600ef1ba); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\abaya\resources\views/components/admin/index.blade.php ENDPATH**/ ?>