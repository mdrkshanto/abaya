<?php if (isset($component)) { $__componentOriginal920bd896de9213e21cff781a16fc9278 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal920bd896de9213e21cff781a16fc9278 = $attributes; } ?>
<?php $component = App\View\Components\Admin\Index::resolve(['title' => 'Orders'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.index'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Admin\Index::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="card card-body">
        <table class="table table-sm table-striped text-center table-responsive">
            <h1 class="text-muted text-center">Your order list</h1>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Customer</th>
                    <th>Customer Mobile</th>
                    <th>Customer Address</th>
                    <th>Status</th>
                    <th>Order Detail</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="fw-bolder"><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($order->name); ?></td>
                        <td><?php echo e($order->mobile); ?></td>
                        <td><?php echo e($order->address); ?></td>
                        <td><?php echo e(ucwords($order->status)); ?></td>
                        <td>
                            <div class="btn-group btn-group-sm">
                                <a class="btn btn-link link-info" href="<?php echo e(route('order', $order->id)); ?>">
                                    <i class="align-middle" data-feather="book-open"></i>
                                </a>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal920bd896de9213e21cff781a16fc9278)): ?>
<?php $attributes = $__attributesOriginal920bd896de9213e21cff781a16fc9278; ?>
<?php unset($__attributesOriginal920bd896de9213e21cff781a16fc9278); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal920bd896de9213e21cff781a16fc9278)): ?>
<?php $component = $__componentOriginal920bd896de9213e21cff781a16fc9278; ?>
<?php unset($__componentOriginal920bd896de9213e21cff781a16fc9278); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\abaya\resources\views/admin/pages/orders/index.blade.php ENDPATH**/ ?>